node db/initDB.js
node db/seedProducts.js
npm start